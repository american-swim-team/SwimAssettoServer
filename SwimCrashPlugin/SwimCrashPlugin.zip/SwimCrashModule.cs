using AssettoServer.Server.Plugin;
using AssettoServer.Server;
using Autofac;
using System.Net.Sockets;

namespace SwimCrashPlugin;

public class SwimCrashModule : AssettoServerModule<SwimCrashConfiguration>
{
    protected override void Load(ContainerBuilder builder)
    {
        // Register other dependencies
        builder.RegisterType<SessionManager>().As<SessionManager>();
        builder.RegisterType<EntryCarManager>().As<EntryCarManager>();
        builder.Register(c => new TcpClient("localhost", 8080)).As<TcpClient>();

        // Register your plugin
        builder.RegisterType<SwimCrashHandler>().AsSelf().AutoActivate().SingleInstance();
    }
}