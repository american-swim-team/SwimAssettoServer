using AssettoServer.Server.Plugin;
using AssettoServer.Server;
using AssettoServer.Shared.Network.Packets.Incoming;
using AssettoServer.Network.ClientMessages;
using System.Numerics;
using AssettoServer.Network.Tcp;
using Serilog;
using Microsoft.Extensions.Hosting;
using System.Net.Sockets;

namespace SwimCrashPlugin;

[OnlineEvent(Key = "noCollision")]
public class noCollision : OnlineEvent<noCollision>
{
    [OnlineEventField(Name = "entryCar")]
    public int EntryCar;
}

public class SwimCrashHandler : BackgroundService, IAssettoServerAutostart
{
    private readonly SessionManager _sessionManager;
    private readonly EntryCarManager _entryCarManager;
    private readonly SwimCrashHandler _plugin;
    private readonly EntryCar _entryCar;
    private bool MonitorGrip { get; set; } = false;
    private long LastCollisionTime { get; set; }
    private Vector3? LastRotation { get; set; }

    public SwimCrashHandler(SignalHandler signalHandler, SessionManager sessionManager, EntryCarManager entryCarManager, SwimCrashHandler plugin, EntryCar entryCar)
    {
        _sessionManager = sessionManager;
        _entryCarManager = entryCarManager;
        _entryCarManager.ClientConnected += OnConnected;
        _entryCarManager.ClientDisconnected += OnDisconnected;
        _plugin = plugin;
        _entryCar = entryCar;
        _entryCar.PositionUpdateReceived += OnPositionUpdateReceived;
    }

    private void OnConnected(ACTcpClient sender, EventArgs e)
    {
        sender.Collision += OnCollision;
    }

    private void OnDisconnected(ACTcpClient sender, EventArgs e)
    {
        sender.Collision -= OnCollision;
    }

    private void OnCollision(object? sender, CollisionEventArgs e) {
        Log.Debug("Collision detected");
        if (e.Speed < 30) {
            return;
        }

        if (MonitorGrip) {
            return;
        } else {
            LastCollisionTime = _sessionManager.ServerTimeMilliseconds;
            MonitorGrip = true;
            LastRotation = null;
        }
    }

    private void OnPositionUpdateReceived(EntryCar sender, in PositionUpdateIn positionUpdate) {

        if (_sessionManager.ServerTimeMilliseconds - LastCollisionTime > 3000) {
            MonitorGrip = false;
            return;
        }

        if (MonitorGrip) {
            if (LastRotation == null) {
                LastRotation = positionUpdate.Rotation;
            }
            if (LastRotation.HasValue) {
                var Time = _sessionManager.ServerTimeMilliseconds - LastCollisionTime;
                // Compute the angular velocity (difference divided by time delta)
                Vector3 angularVelocity = NormalizeAngles(positionUpdate.Rotation - LastRotation.Value) / (Time / 1000f);

                // Calculate the magnitude of the angular velocity
                float angularVelocityMagnitude = MathF.Sqrt(
                    angularVelocity.X * angularVelocity.X +
                    angularVelocity.Y * angularVelocity.Y +
                    angularVelocity.Z * angularVelocity.Z
                );

                // Check if the angular velocity exceeds the threshold
                if (angularVelocityMagnitude > 80)
                {
                    Log.Debug("Car is spinning!");
                }
            }
        }

        LastRotation = positionUpdate.Rotation;
    }

    private float NormalizeAngle(float angle)
    {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }

    private Vector3 NormalizeAngles(Vector3 angles)
    {
        return new Vector3(
            NormalizeAngle(angles.X),
            NormalizeAngle(angles.Y),
            NormalizeAngle(angles.Z)
        );
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        return Task.CompletedTask;
    }
}